#include "dictionnaire.h"
#include "types.h"

int main()
{

Initialiser();

}
