#include "types.h"
#include "dictionnaire.h"
#include <stdio.h>

char * char_to_string(char c);

void decompression(FILE *entree,FILE *sortie);

